module LambdaFunctions
    class PersistAndNotify
      def self.handle(event:, context:)
        print 'Hello World'
      end
    end
  end